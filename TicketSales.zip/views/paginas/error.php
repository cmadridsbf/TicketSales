<main class="pagina_404">
    <h2 class="pagina_404__heading"><?php echo $titulo; ?></h2>

    <div class="pagina_404__contenedor">
        <p class="pagina_404__texto">Tal vez quieras volver al inicio</p>
        <img class="pagina_404__img" src="https://images.unsplash.com/photo-1589652717521-10c0d092dea9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80" alt="404">
        
    </div>
</main>